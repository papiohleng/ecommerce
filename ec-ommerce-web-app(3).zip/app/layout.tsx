import React from "react"
import type { Metadata, Viewport } from 'next'
import { Inter, Playfair_Display } from 'next/font/google'

import './globals.css'

const _inter = Inter({ subsets: ['latin'], variable: '--font-inter' })
const _playfair = Playfair_Display({ subsets: ['latin'], variable: '--font-playfair' })

export const metadata: Metadata = {
  title: 'Maboneng Art | Limited Edition Artwork & eCommerce Platform',
  description: 'Shop exclusive limited edition artwork with massive discounts. Full-stack eCommerce powered by Google Apps Script. Admin dashboard, inventory, orders & financial management.',
  keywords: ['ecommerce', 'art', 'limited edition', 'google apps script', 'maboneng'],
}

export const viewport: Viewport = {
  themeColor: '#0a0a0a',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className="font-sans antialiased">{children}</body>
    </html>
  )
}
