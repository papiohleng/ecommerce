"use client"

import { useState, useEffect, useCallback } from "react"
import { FileCode, FileText, Copy, Check, Download, ChevronRight, ExternalLink, ArrowRight, Database, Globe, Shield, Mail, Code2, Layers, Terminal } from "lucide-react"

const FILES = [
  { name: "Setup.gs", path: "/gas/Setup.gs", type: "gs", description: "Run first. Creates 6 sheets: Inventory, Orders, Transactions, Comments, Deleted, SystemLogs", lines: 233, category: "Backend" },
  { name: "Code.gs", path: "/gas/Code.gs", type: "gs", description: "Main backend. 30+ functions: routing, CRUD, checkout, billing, emails, PDF generation, audit logging", lines: 1068, category: "Backend" },
  { name: "Form.html", path: "/gas/Form.html", type: "html", description: "Public storefront. Dynamic stock levels, cart qty controls with stock enforcement, PayPal/EFT checkout, chatbot, social FAB, image rotation", lines: 550, category: "Frontend" },
  { name: "Submissions.html", path: "/gas/Submissions.html", type: "html", description: "Admin orders dashboard. Full transaction management (add/delete) with auto-updating balance, stats, search/filter, view/email/delete modals, comments", lines: 612, category: "Frontend" },
  { name: "Inventory.html", path: "/gas/Inventory.html", type: "html", description: "Inventory manager. Product cards, stock +/- controls, inline edit modal, low stock alerts, search", lines: 251, category: "Frontend" },
  { name: "newInventory.html", path: "/gas/newInventory.html", type: "html", description: "Add product form. 25+ fields across 5 sections: basic info, specs, pricing, media, additional", lines: 198, category: "Frontend" },
  { name: "Transactions.html", path: "/gas/Transactions.html", type: "html", description: "Financial ledger. 3 tabs: General Ledger, Client Accounts, Profit & Loss with 15% VAT calculations", lines: 355, category: "Frontend" },
  { name: "Deleted.html", path: "/gas/Deleted.html", type: "html", description: "Cancelled orders archive. Soft-delete with restore capability, permanent purge, search, reason tracking", lines: 185, category: "Frontend" },
]

const DEPLOY_STEPS = [
  { step: 1, title: "Open Your Spreadsheet", desc: "Open Google Spreadsheet ID: 1NnsMcz3r6yGfzkXhI3SyF5RwMfKTR2USrxt89Qn5gfI (your IDs are pre-filled in the code)." },
  { step: 2, title: "Open Apps Script FROM the Spreadsheet", desc: "CRITICAL: Go to Extensions > Apps Script. This makes it container-bound to the spreadsheet. Do NOT create a standalone Apps Script project." },
  { step: 3, title: "Rename default file to Setup", desc: "The editor opens with a default Code.gs file. Rename it to 'Setup' (click the 3 dots next to Code.gs > Rename). Paste the Setup.gs content. Run runSetup() to create all 6 sheets." },
  { step: 4, title: "Create Code.gs file", desc: "Click the + button next to Files > Script. Name it 'Code'. Paste the ENTIRE Code.gs content. The file must be named exactly 'Code' (GAS adds .gs automatically)." },
  { step: 5, title: "Create all 6 HTML files", desc: "Click + > HTML for EACH: Form, Submissions, Inventory, newInventory, Transactions, Deleted. Names must be EXACT (case-sensitive). Paste each file's content." },
  { step: 6, title: "Save All Files", desc: "Press Ctrl+S or click the save icon. All 8 files (Setup.gs, Code.gs, 6 HTML) must be saved. Check for red error icons." },
  { step: 7, title: "Deploy as Web App", desc: "Click Deploy > New deployment > Web app. Execute as: 'Me'. Who has access: 'Anyone'. Click Deploy. Copy the web app URL. Add ?action=orders for admin, ?action=inventory for inventory, etc." },
  { step: 8, title: "Re-deploy after changes", desc: "After ANY code change: Deploy > Manage deployments > Edit (pencil icon) > Version: 'New version' > Deploy. The URL stays the same but serves updated code." },
]

const ARCHITECTURE = [
  { icon: Database, label: "Google Sheets", desc: "6-sheet database with 100+ columns" },
  { icon: Code2, label: "Apps Script", desc: "30+ server functions, REST API routing" },
  { icon: Globe, label: "Web App", desc: "6 HTML pages served via doGet() routing" },
  { icon: Mail, label: "Email System", desc: "Order confirmations, statements, custom emails" },
  { icon: Shield, label: "Security", desc: "LockService concurrency, input sanitization" },
  { icon: Layers, label: "Audit Trail", desc: "SystemLogs + Comments event sourcing" },
]

export default function DeploymentGuidePage() {
  const [selectedFile, setSelectedFile] = useState<typeof FILES[0] | null>(null)
  const [fileContent, setFileContent] = useState("")
  const [loading, setLoading] = useState(false)
  const [copied, setCopied] = useState(false)
  const [activeTab, setActiveTab] = useState<"files" | "deploy" | "arch">("files")

  const loadFile = useCallback(async (file: typeof FILES[0]) => {
    setSelectedFile(file)
    setLoading(true)
    try {
      const res = await fetch(file.path)
      const text = await res.text()
      setFileContent(text)
    } catch {
      setFileContent("// Error loading file")
    }
    setLoading(false)
  }, [])

  useEffect(() => {
    loadFile(FILES[0])
  }, [loadFile])

  const copyToClipboard = async () => {
    await navigator.clipboard.writeText(fileContent)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const downloadFile = () => {
    if (!selectedFile) return
    const blob = new Blob([fileContent], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = selectedFile.name
    a.click()
    URL.revokeObjectURL(url)
  }

  const downloadAll = async () => {
    for (const file of FILES) {
      try {
        const res = await fetch(file.path)
        const text = await res.text()
        const blob = new Blob([text], { type: "text/plain" })
        const url = URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = file.name
        a.click()
        URL.revokeObjectURL(url)
        await new Promise(r => setTimeout(r, 300))
      } catch { /* skip */ }
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-primary">Maboneng Art</h1>
            <p className="text-sm text-muted-foreground">Google Apps Script eCommerce Platform</p>
          </div>
          <button
            onClick={downloadAll}
            className="flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded-lg font-semibold text-sm hover:opacity-90 transition-opacity"
          >
            <Download className="w-4 h-4" />
            Download All Files
          </button>
        </div>
      </header>

      {/* Stats Bar */}
      <div className="border-b border-border bg-card/50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex gap-6 overflow-x-auto text-sm">
          <span className="text-muted-foreground whitespace-nowrap">8 Files</span>
          <span className="text-muted-foreground whitespace-nowrap">3,450+ Lines</span>
          <span className="text-muted-foreground whitespace-nowrap">2 Backend (.gs)</span>
          <span className="text-muted-foreground whitespace-nowrap">6 Frontend (.html)</span>
          <span className="text-muted-foreground whitespace-nowrap">6 Database Sheets</span>
          <span className="text-muted-foreground whitespace-nowrap">30+ Server Functions</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="max-w-7xl mx-auto px-4 pt-4">
        <div className="flex gap-1 bg-secondary rounded-lg p-1 w-fit">
          {(["files", "deploy", "arch"] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-md text-sm font-semibold transition-all ${
                activeTab === tab
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {tab === "files" ? "Source Files" : tab === "deploy" ? "Deployment Guide" : "Architecture"}
            </button>
          ))}
        </div>
      </div>

      {/* FILES TAB */}
      {activeTab === "files" && (
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex gap-4" style={{ minHeight: "calc(100vh - 220px)" }}>
            {/* File List Sidebar */}
            <div className="w-72 flex-shrink-0 space-y-1">
              <p className="text-xs font-semibold text-primary uppercase tracking-wider mb-3 px-2">Project Files</p>
              {FILES.map(file => (
                <button
                  key={file.name}
                  onClick={() => loadFile(file)}
                  className={`w-full text-left px-3 py-3 rounded-lg transition-all group ${
                    selectedFile?.name === file.name
                      ? "bg-primary/10 border border-primary/30"
                      : "hover:bg-secondary border border-transparent"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {file.type === "gs" ? (
                      <FileCode className="w-4 h-4 text-primary flex-shrink-0" />
                    ) : (
                      <FileText className="w-4 h-4 text-blue-400 flex-shrink-0" />
                    )}
                    <span className="font-semibold text-sm">{file.name}</span>
                    <ChevronRight className={`w-3 h-3 ml-auto transition-transform ${selectedFile?.name === file.name ? "rotate-90 text-primary" : "text-muted-foreground"}`} />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1 leading-relaxed line-clamp-2 pl-6">{file.description}</p>
                  <div className="flex gap-3 mt-1.5 pl-6">
                    <span className="text-xs text-muted-foreground">{file.lines} lines</span>
                    <span className={`text-xs font-semibold ${file.category === "Backend" ? "text-primary" : "text-blue-400"}`}>{file.category}</span>
                  </div>
                </button>
              ))}
            </div>

            {/* Code Viewer */}
            <div className="flex-1 min-w-0 bg-card border border-border rounded-xl overflow-hidden flex flex-col">
              {selectedFile && (
                <>
                  <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-secondary/30">
                    <div className="flex items-center gap-2">
                      {selectedFile.type === "gs" ? (
                        <FileCode className="w-4 h-4 text-primary" />
                      ) : (
                        <FileText className="w-4 h-4 text-blue-400" />
                      )}
                      <span className="font-semibold text-sm">{selectedFile.name}</span>
                      <span className="text-xs text-muted-foreground">({selectedFile.lines} lines)</span>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={copyToClipboard}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-secondary rounded-md text-xs font-semibold hover:bg-secondary/80 transition-colors"
                      >
                        {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                        {copied ? "Copied!" : "Copy"}
                      </button>
                      <button
                        onClick={downloadFile}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-xs font-semibold hover:opacity-90 transition-opacity"
                      >
                        <Download className="w-3.5 h-3.5" />
                        Download
                      </button>
                    </div>
                  </div>
                  <div className="flex-1 overflow-auto">
                    {loading ? (
                      <div className="p-8 text-center text-muted-foreground">Loading...</div>
                    ) : (
                      <pre className="p-4 text-xs leading-relaxed font-mono overflow-x-auto whitespace-pre">
                        <code>{fileContent}</code>
                      </pre>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* DEPLOY TAB */}
      {activeTab === "deploy" && (
        <div className="max-w-3xl mx-auto px-4 py-6 space-y-4">
          <div className="bg-card border border-primary/30 rounded-xl p-6 mb-6">
            <h2 className="text-xl font-bold text-primary mb-2">Deployment Guide</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Follow these 8 steps to deploy the complete Maboneng Art eCommerce platform on Google Apps Script. The entire application runs on Google Sheets as a database with HTML/CSS/JS frontend served via Apps Script web app deployment.
            </p>
          </div>

          {DEPLOY_STEPS.map(step => (
            <div key={step.step} className="flex gap-4 items-start group">
              <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm flex-shrink-0">
                {step.step}
              </div>
              <div className="flex-1 bg-card border border-border rounded-xl p-5 group-hover:border-primary/30 transition-colors">
                <h3 className="font-bold text-base mb-1">{step.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{step.desc}</p>
              </div>
            </div>
          ))}

          <div className="bg-card border border-border rounded-xl p-6 mt-6">
            <h3 className="font-bold text-primary mb-3">After Deployment</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2"><ArrowRight className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" /> Visit your web app URL to see the storefront (Form.html)</li>
              <li className="flex items-start gap-2"><ArrowRight className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" /> Add <code className="bg-secondary px-1 rounded text-xs">?action=admin</code> to access the orders dashboard</li>
              <li className="flex items-start gap-2"><ArrowRight className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" /> Add <code className="bg-secondary px-1 rounded text-xs">?action=inventory</code> for inventory management</li>
              <li className="flex items-start gap-2"><ArrowRight className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" /> Add <code className="bg-secondary px-1 rounded text-xs">?action=transactions</code> for the financial ledger</li>
              <li className="flex items-start gap-2"><ArrowRight className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" /> Add <code className="bg-secondary px-1 rounded text-xs">?action=deleted</code> for the cancelled orders archive</li>
              <li className="flex items-start gap-2"><ArrowRight className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" /> Add <code className="bg-secondary px-1 rounded text-xs">?action=new-inventory</code> to add new products</li>
            </ul>
          </div>
        </div>
      )}

      {/* ARCHITECTURE TAB */}
      {activeTab === "arch" && (
        <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
          <div className="bg-card border border-primary/30 rounded-xl p-6">
            <h2 className="text-xl font-bold text-primary mb-2">System Architecture</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              The Maboneng Art platform is a full-stack eCommerce system built entirely on Google Apps Script. It uses Google Sheets as a relational database with 6 sheets (100+ columns), server-side functions for business logic, and HTML/CSS/JS for the frontend.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            {ARCHITECTURE.map(item => (
              <div key={item.label} className="bg-card border border-border rounded-xl p-5 hover:border-primary/30 transition-colors">
                <item.icon className="w-8 h-8 text-primary mb-3" />
                <h3 className="font-bold text-sm mb-1">{item.label}</h3>
                <p className="text-xs text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>

          <div className="bg-card border border-border rounded-xl p-6">
            <h3 className="font-bold text-primary mb-4">Data Model</h3>
            <div className="font-mono text-xs text-muted-foreground leading-relaxed whitespace-pre">{`
Inventory (30 cols) - Product catalog source of truth
    |
    v [storefront API]
Orders (26 cols) - Customer orders from checkout
    |
    +---< Transactions (8 cols) - Financial ledger [1:N]
    |
    +---< Comments (5 cols) - Event log / audit [1:N]
    |
    +---< Deleted (5 cols) - Tombstone pattern [1:1]

SystemLogs (5 cols) - Global audit trail

Routing: doGet(e) -> ?action=form|admin|inventory|...
         doPost(e) -> JSON action dispatch
            `}</div>
          </div>

          <div className="bg-card border border-border rounded-xl p-6">
            <h3 className="font-bold text-primary mb-4">Key Features</h3>
            <div className="grid grid-cols-1 gap-3 text-sm md:grid-cols-2">
              {[
                "Dynamic stock levels updated as admin changes inventory",
                "Cart quantity +/- controls with stock enforcement",
                "Transaction management (add/delete) with auto-balance updates",
                "Auto-rotating product images (5s interval)",
                "Fly-to-cart animation on add",
                "PayPal + EFT dual checkout",
                "Expandable social media FAB",
                "Context-aware chatbot widget",
                "Urgency countdown banner",
                "7 sort options + category filtering",
                "Wishlist with localStorage persistence",
                "Order status workflow (new > processing > shipped > delivered)",
                "Inline field editing with auto-save",
                "Comment system with SYSTEM/Admin/BILLING authors",
                "Soft-delete with snapshot restore",
                "General Ledger + Client Accounts + P&L tabs",
                "15% VAT calculation",
                "PDF invoice generation",
                "Automated confirmation emails with HTML templates",
                "Custom email modal from admin",
                "Statement email per client",
                "LockService for concurrent writes",
                "Input sanitization + XSS prevention",
                "UUID-based record IDs",
                "Dark/Light theme toggle on every page",
                "Full mobile responsive design",
                "Demo fallback mode for offline/preview",
              ].map(feature => (
                <div key={feature} className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                  <span className="text-muted-foreground">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-border mt-12 py-6 text-center text-xs text-muted-foreground">
        <p>Maboneng Art eCommerce Platform - Pure Google Apps Script Web App</p>
        <p className="mt-1">8 files, 3,450+ lines, 6 sheets, 30+ server functions</p>
      </footer>
    </div>
  )
}
